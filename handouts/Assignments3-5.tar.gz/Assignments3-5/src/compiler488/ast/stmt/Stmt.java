package compiler488.ast.stmt;

import compiler488.ast.Indentable;

/**
 * A placeholder for statements.
 */
public class Stmt extends Indentable {
}
